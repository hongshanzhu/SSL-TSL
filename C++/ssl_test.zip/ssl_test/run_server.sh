#!/bin/sh
./ssl_server 7838 1 127.0.0.1 cacert.pem privkey.pem 
